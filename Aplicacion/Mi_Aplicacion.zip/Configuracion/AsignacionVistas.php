<?php
	
	abstract class NeuralAsignacionVistas {
		
		/**
		 * SeleccionVista($Vista)
		 * 
		 * Se ingresan el orden de las vistas en un array no asociativo 
		 * Ejemplo: $Array[]=array('archivo.php', 'carpeta/archivo.php', 'NOMBREARCHIVO');
		 * el termino "NOMBREARCHIVO": es el nombre asignado para a�adir el archivo creado para agregar la informacion
		 * Recordar: estos archivos se crearan dentro de la ruta de la siguiente ruta:
		 * Aplicacion/Nombre de la Aplicacion/vistas/
		 */
		public static function SeleccionVista($Vista = 0) {
			
			$Array[0] = array(
					'NOMBREARCHIVO'
			);
			
			/**********************NO EDITAR**************************/
			
			
			return SysMisNeural::ValidarAsignacionVista($Array, $Vista);
		}
	}