<?php
	
	class Index extends Controlador {
		
		function __Construct() {
			parent::__Construct();
		}
		
		public function Index() {
			
			echo 'Bienvenido esta es MI_APLICACION';
		}
	}