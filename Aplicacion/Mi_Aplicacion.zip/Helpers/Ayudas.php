<?php
	
	abstract class Ayudas {
		
		public static function Print__R($Array) {
			
			echo '<code><pre>';
			print_r($Array);
			echo '</pre></code>';
		}
	}